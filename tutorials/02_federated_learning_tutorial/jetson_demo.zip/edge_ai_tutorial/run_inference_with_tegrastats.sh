#!/usr/bin/env bash
# Run tegrastats for 10s baseline, then run inference.py while logging, then stop and plot.
# Usage: ./run_inference_with_tegrastats.sh              # runs inference.py --batch 8
#        ./run_inference_with_tegrastats.sh --batch 4    # runs inference.py --batch 4
#        (may need: sudo ./run_inference_with_tegrastats.sh)
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/tegrastats.log"
INFERENCE_SCRIPT="${SCRIPT_DIR}/inference.py"
PLOT_SCRIPT="${SCRIPT_DIR}/plot_tegrastats.py"

# 1. Start tegrastats in background and record for 10s baseline
echo "[1/4] Starting tegrastats (baseline 10s)..."
: > "$LOG_FILE"
# Start tegrastats (use --interval 500 for 500ms sampling if your build supports it)
tegrastats >> "$LOG_FILE" 2>&1 &
TEGRA_PID=$!
sleep 10

# 2. Run inference.py (foreground). Pass script args, e.g. --batch 8 (default: --batch 8)
INFERENCE_ARGS=("--batch" "8")
if [[ $# -gt 0 ]]; then
  INFERENCE_ARGS=("$@")
fi
echo "[2/4] Running inference.py ${INFERENCE_ARGS[*]}..."
python3 "$INFERENCE_SCRIPT" "${INFERENCE_ARGS[@]}"

# 3. Stop tegrastats once inference exits
echo "[3/4] Stopping tegrastats..."
kill "$TEGRA_PID" 2>/dev/null || true
wait "$TEGRA_PID" 2>/dev/null || true

# 4. Log file already stored at LOG_FILE
echo "[4/4] Tegrastats log: $LOG_FILE"

# 5. Plot GPU / RAM / CPU time series
if [[ -f "$PLOT_SCRIPT" ]]; then
  echo "Plotting GPU, RAM, CPU utilization..."
  python3 "$PLOT_SCRIPT"
else
  echo "Plot script not found: $PLOT_SCRIPT"
fi

echo "Done."
