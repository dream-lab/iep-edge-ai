import argparse
import os
import logging
import warnings
from typing import List

# Keep console output clean (set these to "0" / remove to re-enable)
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")

warnings.filterwarnings(
    "ignore",
    message=r"Warning: You are sending unauthenticated requests to the HF Hub\..*",
)

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers.generation.streamers import TextIteratorStreamer
import threading

# ── Config ──────────────────────────────────────────────────────────────────
MODEL_ID = "HuggingFaceTB/SmolLM2-135M-Instruct"   # ~270 MB, runs fine on any CUDA GPU
DEVICE   = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE    = torch.float16 if DEVICE == "cuda" else torch.float32
CACHE_DIR = "" # set this to where you want to store the model

print(f"Using device : {DEVICE}")
print(f"Using dtype  : {DTYPE}\n")

# Reduce noisy library logging (keeps your own prints)
logging.getLogger("transformers").setLevel(logging.ERROR)
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

# ── Load model & tokenizer ───────────────────────────────────────────────────
print("Loading tokenizer …")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, cache_dir=CACHE_DIR)

print("Loading model …")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    dtype=DTYPE,
    device_map="auto",
    cache_dir=CACHE_DIR,      # lets accelerate place layers on GPU automatically
)
model.eval()
print("Model ready!\n")

# ── Inference ────────────────────────────────────────────────────────────────
def generate_stream(prompt: str, max_new_tokens: int = 200):
    # SmolLM2-Instruct expects a chat template
    messages = [{"role": "user", "content": prompt}]
    formatted = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )

    inputs = tokenizer(formatted, return_tensors="pt").to(DEVICE)

    streamer = TextIteratorStreamer(
        tokenizer,
        skip_prompt=True,
        skip_special_tokens=True,
    )

    generation_kwargs = dict(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,
        pad_token_id=tokenizer.eos_token_id,
        streamer=streamer,
    )

    def _run_generate():
        with torch.no_grad():
            model.generate(**generation_kwargs)

    t = threading.Thread(target=_run_generate, daemon=True)
    t.start()

    for text in streamer:
        yield text


def generate(prompt: str, max_new_tokens: int = 200) -> str:
    chunks = []
    for chunk in generate_stream(prompt, max_new_tokens=max_new_tokens):
        chunks.append(chunk)
    return "".join(chunks)


def generate_and_print(prompt: str, max_new_tokens: int = 200) -> None:
    for chunk in generate_stream(prompt, max_new_tokens=max_new_tokens):
        print(chunk, end="", flush=True)
    print()


def _format_prompt_for_chat(prompt: str):
    messages = [{"role": "user", "content": prompt}]
    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def generate_batch(prompts: List[str], max_new_tokens: int = 200) -> List[str]:
    """Run batched inference; returns list of generated texts (one per prompt)."""
    if not prompts:
        return []
    formatted = [_format_prompt_for_chat(p) for p in prompts]
    inputs = tokenizer(
        formatted,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to(DEVICE)
    input_lengths = inputs["attention_mask"].sum(dim=1)

    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id,
        )

    results = []
    for i in range(output_ids.shape[0]):
        start = int(input_lengths[i].item())
        new_ids = output_ids[i, start:]
        results.append(tokenizer.decode(new_ids, skip_special_tokens=True))
    return results


MAX_BATCH_SIZE = 8
BATCH_PROMPTS = [
    "Explain what a transformer neural network is in simple terms.",
    "Give me 3 bullet points comparing CNNs vs Transformers for vision.",
    "Summarize why attention helps with long-range dependencies.",
    "Write a short analogy for self-attention for a beginner.",
    "What is a token in LLMs? Explain in 2 sentences.",
    "List common decoding strategies: greedy, beam, top-k, top-p.",
    "Explain KV cache and why it speeds up generation.",
    "Give a 1-paragraph overview of fine-tuning vs prompt engineering.",
]


# ── Run ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run SmolLM inference (single or batched).")
    parser.add_argument(
        "--batch",
        nargs="?",
        const=MAX_BATCH_SIZE,
        default=None,
        type=int,
        metavar="SIZE",
        help="Run batched inference. Optional SIZE (default %d, cap %d)." % (MAX_BATCH_SIZE, MAX_BATCH_SIZE),
    )
    args = parser.parse_args()

    if args.batch is not None:
        size = min(args.batch, MAX_BATCH_SIZE)
        prompts = BATCH_PROMPTS[:size]
        print(f"Batched inference (batch_size={len(prompts)})\n")
        responses = generate_batch(prompts)
        for i, (p, r) in enumerate(zip(prompts, responses), start=1):
            print(f"--- Prompt {i} ---")
            print(p)
            print("Response:")
            print(r.strip())
            print()
    else:
        prompt = "Explain what a transformer neural network is in simple terms."
        print(f"Prompt : {prompt}\n")
        print("Response:")
        generate_and_print(prompt)