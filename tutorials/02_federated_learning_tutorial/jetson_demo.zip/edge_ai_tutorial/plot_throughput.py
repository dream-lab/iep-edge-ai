"""
Plot batch size vs throughput from inference_batched_results.csv.
Usage: python plot_throughput.py
"""
import os

import pandas as pd
import matplotlib.pyplot as plt

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(SCRIPT_DIR, "inference_batched_results.csv")
OUT_PATH = os.path.join(SCRIPT_DIR, "throughput_vs_batch_size.png")

def main():
    df = pd.read_csv(CSV_PATH)
    df = df.sort_values("batch_size")

    fig, ax = plt.subplots()
    ax.plot(df["batch_size"], df["throughput_tok_s"], marker="o", linewidth=2, markersize=8)
    ax.set_xlabel("Batch size")
    ax.set_ylabel("Throughput (tokens/s)")
    ax.set_title("Throughput vs batch size")
    ax.set_xticks(df["batch_size"])
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT_PATH, dpi=150)
    print(f"Saved: {OUT_PATH}")
    plt.show()

if __name__ == "__main__":
    main()
