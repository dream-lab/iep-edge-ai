import csv
import os
import time
import logging
import warnings
from typing import List, Dict, Any, Tuple

# Keep console output clean (set these to "0" / remove to re-enable)
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")

warnings.filterwarnings(
    "ignore",
    message=r"Warning: You are sending unauthenticated requests to the HF Hub\..*",
)

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM


# ── Config ──────────────────────────────────────────────────────────────────
MODEL_ID = "HuggingFaceTB/SmolLM2-135M-Instruct"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32
CACHE_DIR = "/media/ssd/mayank/edge_ai_tutorial/model_cache"

MAX_NEW_TOKENS = 200
# Exactly 4 batches: one of size 1, then 2, then 4, then 8 (1 req, 2 req, 4 req, 8 req)
BATCH_SIZES = [1, 2, 4, 8]
NUM_PROMPTS = 8  # need 8 prompts for the size-8 batch
RESULTS_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "inference_batched_results.csv")

GEN_KWARGS: Dict[str, Any] = dict(
    max_new_tokens=MAX_NEW_TOKENS,
    do_sample=True,
    temperature=0.2,
    top_p=0.9,
)


def _sync_if_cuda() -> None:
    if DEVICE == "cuda":
        torch.cuda.synchronize()


def _format_prompts(prompts: List[str], tokenizer) -> List[str]:
    formatted: List[str] = []
    for p in prompts:
        messages = [{"role": "user", "content": p}]
        formatted.append(
            tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
        )
    return formatted


def _count_input_tokens(inputs) -> int:
    # attention_mask is 1 for real tokens, 0 for padding
    if "attention_mask" in inputs:
        return int(inputs["attention_mask"].sum().item())
    return int(inputs["input_ids"].numel())


def _count_output_tokens(output_ids: torch.Tensor, input_lengths: torch.Tensor) -> int:
    # output_ids: [B, T_total], input_lengths: [B]
    # count non-pad tokens beyond each prompt length
    bsz = output_ids.shape[0]
    out = 0
    for i in range(bsz):
        out += int(output_ids[i].shape[0] - int(input_lengths[i].item()))
    return out


def run_batch(prompts: List[str], tokenizer, model) -> Tuple[float, int, int]:
    formatted = _format_prompts(prompts, tokenizer)
    inputs = tokenizer(
        formatted,
        return_tensors="pt",
        padding=True,
        truncation=False,
    ).to(DEVICE)

    input_lengths = inputs["attention_mask"].sum(dim=1) if "attention_mask" in inputs else torch.full(
        (inputs["input_ids"].shape[0],), inputs["input_ids"].shape[1], device=inputs["input_ids"].device
    )

    input_tok = _count_input_tokens(inputs)

    _sync_if_cuda()
    t0 = time.perf_counter()
    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            **GEN_KWARGS,
            pad_token_id=tokenizer.eos_token_id,
        )
    _sync_if_cuda()
    dt = time.perf_counter() - t0

    output_tok = _count_output_tokens(output_ids, input_lengths)
    return dt, input_tok, output_tok


def chunked(items: List[str], n: int) -> List[List[str]]:
    return [items[i : i + n] for i in range(0, len(items), n)]


if __name__ == "__main__":
    print(f"Using device : {DEVICE}")
    print(f"Using dtype  : {DTYPE}")
    print(f"Cache dir    : {CACHE_DIR}\n")

    # Reduce noisy library logging (keeps your own prints)
    logging.getLogger("transformers").setLevel(logging.ERROR)
    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

    print("Loading tokenizer …")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, cache_dir=CACHE_DIR)

    print("Loading model …")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        dtype=DTYPE,
        device_map="auto",
        cache_dir=CACHE_DIR,
    )
    model.eval()
    print("Model ready!\n")

    # 8 different prompts (edit these as you like)
    prompts = [
        "Explain what a transformer neural network is in simple terms.",
        "Give me 3 bullet points comparing CNNs vs Transformers for vision.",
        "Summarize why attention helps with long-range dependencies.",
        "Write a short analogy for self-attention for a beginner.",
        "What is a token in LLMs? Explain in 2 sentences.",
        "List common decoding strategies: greedy, beam, top-k, top-p.",
        "Explain KV cache and why it speeds up generation.",
        "Give a 1-paragraph overview of fine-tuning vs prompt engineering.",
    ]
    prompts = prompts[:NUM_PROMPTS]

    # CSV header and rows for plotting (one row per batch)
    csv_rows = []
    csv_headers = [
        "batch_size",
        "total_time_s",
        "total_input_tokens",
        "total_output_tokens",
        "total_tokens",
        "throughput_tok_s",
    ]

    print("Throughput = (input_tokens + output_tokens) / seconds.\n")
    print("-" * 72)

    # Exactly 4 batches: size 1 (1 req), then 2, then 4, then 8
    for bi, batch_size in enumerate(BATCH_SIZES, start=1):
        batch_prompts = prompts[:batch_size]
        dt, in_tok, out_tok = run_batch(batch_prompts, tokenizer, model)
        tot_tok = in_tok + out_tok
        tps = (tot_tok / dt) if dt > 0 else 0.0

        print(
            f"\nBatch {bi} (size={batch_size}, {len(batch_prompts)} req) | "
            f"time={dt:.3f}s | in={in_tok} out={out_tok} total={tot_tok} tok | {tps:.1f} tok/s"
        )

        csv_rows.append({
            "batch_size": batch_size,
            "total_time_s": f"{dt:.4f}",
            "total_input_tokens": in_tok,
            "total_output_tokens": out_tok,
            "total_tokens": tot_tok,
            "throughput_tok_s": f"{tps:.2f}",
        })

    print("\n" + "-" * 72)
    print("Summary (saved to CSV):")
    for r in csv_rows:
        print(f"  batch_size={r['batch_size']}  throughput={r['throughput_tok_s']} tok/s")

    with open(RESULTS_CSV, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=csv_headers)
        w.writeheader()
        w.writerows(csv_rows)
    print(f"\nResults written to: {RESULTS_CSV}")
