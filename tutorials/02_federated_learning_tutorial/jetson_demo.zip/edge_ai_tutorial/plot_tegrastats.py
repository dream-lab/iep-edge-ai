"""
Parse tegrastats log and plot GPU, RAM, CPU utilization time series.
Usage: python plot_tegrastats.py [tegrastats.log]
"""
import re
import sys
import os

import matplotlib.pyplot as plt
import numpy as np

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_LOG = os.path.join(SCRIPT_DIR, "tegrastats.log")
OUT_PATH = os.path.join(SCRIPT_DIR, "tegrastats_utilization.png")


def parse_tegrastats_line(line: str):
    """Extract RAM%, CPU%, GPU% from one tegrastats line. Returns (ram_pct, cpu_pct, gpu_pct) or None."""
    # RAM: "RAM 2547/7774MB" or "RAM 220/38955MB"
    ram_m = re.search(r"RAM\s+(\d+)/(\d+)\s*MB", line, re.IGNORECASE)
    ram_pct = None
    if ram_m:
        used, total = int(ram_m.group(1)), int(ram_m.group(2))
        ram_pct = 100.0 * used / total if total else 0

    # CPU: "CPU [28%]" or "CPU [1%@102,5%@102,...]" or "CPU [2%,off,off,...]"
    cpu_pct = None
    cpu_block = re.search(r"CPU\s+\[([^\]]+)\]", line, re.IGNORECASE)
    if cpu_block:
        parts = re.findall(r"(\d+)%", cpu_block.group(1))
        if parts:
            cpu_pct = np.mean([int(p) for p in parts])

    # GPU: "GR3D_FREQ 45%@..." or "GR3D 45%@..."
    gpu_m = re.search(r"GR3D(?:_FREQ)?\s*(\d+)%", line, re.IGNORECASE)
    gpu_pct = int(gpu_m.group(1)) if gpu_m else None

    if ram_pct is None and cpu_pct is None and gpu_pct is None:
        return None
    return (ram_pct, cpu_pct, gpu_pct)


def parse_log(path: str):
    """Return (times, ram_pcts, cpu_pcts, gpu_pcts). Time is sample index (0,1,2,...)."""
    times, rams, cpus, gpus = [], [], [], []
    with open(path) as f:
        for i, line in enumerate(f):
            parsed = parse_tegrastats_line(line)
            if parsed is None:
                continue
            ram_pct, cpu_pct, gpu_pct = parsed
            times.append(i)
            rams.append(ram_pct if ram_pct is not None else np.nan)
            cpus.append(cpu_pct if cpu_pct is not None else np.nan)
            gpus.append(gpu_pct if gpu_pct is not None else np.nan)
    return np.array(times), np.array(rams), np.array(cpus), np.array(gpus)


def main():
    log_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_LOG
    if not os.path.isfile(log_path):
        print(f"Log not found: {log_path}")
        sys.exit(1)

    t, ram, cpu, gpu = parse_log(log_path)
    if len(t) == 0:
        print("No parseable tegrastats lines found.")
        sys.exit(1)

    # Assume ~1 sample per second if no timestamp; scale by 0.5 if you used --interval 500
    # Use sample index as x; label can stay "Sample" or we use "Time (s)" with interval
    x = t.astype(float)  # optional: * 0.5 for 500ms interval
    xlabel = "Sample"

    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(10, 7))

    axes[0].plot(x, ram, color="C0", linewidth=1)
    axes[0].set_ylabel("RAM util (%)")
    axes[0].set_title("RAM utilization")
    axes[0].grid(True, alpha=0.3)
    axes[0].set_ylim(0, 105)

    axes[1].plot(x, cpu, color="C1", linewidth=1)
    axes[1].set_ylabel("CPU util (%)")
    axes[1].set_title("CPU utilization")
    axes[1].grid(True, alpha=0.3)
    axes[1].set_ylim(0, 105)

    axes[2].plot(x, gpu, color="C2", linewidth=1)
    axes[2].set_ylabel("GPU util (%)")
    axes[2].set_xlabel(xlabel)
    axes[2].set_title("GPU utilization")
    axes[2].grid(True, alpha=0.3)
    axes[2].set_ylim(0, 105)

    fig.suptitle("Tegrastats: GPU, RAM, CPU utilization (time series)")
    fig.tight_layout()
    fig.savefig(OUT_PATH, dpi=150)
    print(f"Saved: {OUT_PATH}")
    plt.show()


if __name__ == "__main__":
    main()
